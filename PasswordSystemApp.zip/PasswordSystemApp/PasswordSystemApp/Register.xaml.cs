﻿using System;
using System.IO;
using System.Windows;
using BCrypt.Net;
using PasswordSystemApp.Classes;

namespace PasswordSystemApp
{
    public partial class Register : Window
    {
        private const string EncryptionKey = "passwordaeskeyfopasswordaeskeyfo";

        public Register()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string fullName = FullName.Text;
            string password = Password.Password;

            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
            string filePath = $"{fullName}.txt";
            FileManager fileManager = new FileManager(filePath, EncryptionKey);
            fileManager.CreateFile();

            User user = new User
            {
                FullName = fullName,
                EncryptedPassword = hashedPassword
            };
            SaveUserToFile(user, filePath);

            fileManager.EncryptFile();

            MessageBox.Show("Registration Successful!");

        
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void SaveUserToFile(User user, string filePath)
        {
            string userData = $"{user.FullName},{user.EncryptedPassword}";

            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine(userData);
            }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }
    }
}
