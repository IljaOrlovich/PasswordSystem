﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PasswordSystemApp
{
    /// <summary>
    /// Interaction logic for UpdatePswWindow.xaml
    /// </summary>
    public partial class UpdatePswWindow : Window
    {
        public UpdatePswWindow()
        {
            InitializeComponent();
        }

        private void UpdatePassword_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string newPassword = txtNewPassword.Password;

            Classes.FileManager fileManager = new Classes.FileManager("passwords.txt", "passwordaeskeyfopasswordaeskeyfo");

            
            fileManager.UpdatePassword(name, newPassword);

            MessageBox.Show("Password updated successfully!");
        }


        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
            this.Close();
        }
    }
}
