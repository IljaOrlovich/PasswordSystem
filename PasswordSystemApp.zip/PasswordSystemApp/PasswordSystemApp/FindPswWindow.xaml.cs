﻿using PasswordSystemApp.Classes;
using System;
using System.Windows;

namespace PasswordSystemApp
{
    /// <summary>
    /// Interaction logic for FindPswWindow.xaml
    /// </summary>
    public partial class FindPswWindow : Window
    {
        private FileManager fileManager;
        private string foundPassword;

        public FindPswWindow()
        {
            InitializeComponent();
            string encryptionKey = "passwordaeskeyfopasswordaeskeyfo";
            string filePath = "passwords.txt";
            fileManager = new FileManager(filePath, encryptionKey);
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Name field is required.");
                return;
            }

            var record = fileManager.FindPasswordByName(name);
            if (record != null)
            {
                UsernameLabel.Text = $"Name: {record[0]}";
                PasswordLabel.Text = $"Password: {record[1]} (encrypted)";
                foundPassword = record[1];
                UsernameLabel.Visibility = Visibility.Visible;
                PasswordLabel.Visibility = Visibility.Visible;
                ShowUnencryptedPasswordButton.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("No password found with the given name.");
            }
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
            this.Close();
        }

        private void ShowUnencryptedPassword_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var decryptedPassword = RSAHelper.Decrypt(foundPassword);
                MessageBox.Show($"Unencrypted Password: {decryptedPassword}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error decrypting password: {ex.Message}");
            }
        }
    }
}
