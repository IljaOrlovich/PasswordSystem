﻿using PasswordSystemApp.Classes;
using System;
using System.Windows;

namespace PasswordSystemApp
{
    public partial class AddPswWindow : Window
    {
        private FileManager fileManager;

        public AddPswWindow()
        {
            InitializeComponent();
            string encryptionKey = "passwordaeskeyfopasswordaeskeyfo";
            string filePath = "passwords.txt";
            fileManager = new FileManager(filePath, encryptionKey);
        }

        private void GeneratePassword_Click(object sender, RoutedEventArgs e)
        {
            string generatedPassword = PasswordGenerator.GenerateRandomPassword();
            Password.Text = generatedPassword;
        }

        private void CopyPassword_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(Password.Text);
            MessageBox.Show("Password copied to clipboard!");
        }

        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
            this.Close();
        }

        private void AddPassword_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;
            string password = Password.Text;
            string urlOrApp = txtUrlOrApp.Text;
            string comment = txtComment.Text;

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Name and Password fields are required.");
                return;
            }

            fileManager.AddPassword(name, password, urlOrApp, comment);
            MessageBox.Show("Password added successfully!");
        }
    }
}
