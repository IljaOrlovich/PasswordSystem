﻿using PasswordSystemApp.Classes;
using System.Configuration;
using System.Data;
using System.IO;
using System.Windows;

namespace PasswordSystemApp
{
    public partial class App : Application
    {
        private string filePath = "passwords.txt";
        
        private string encryptionKey = "passwordaeskeyfopasswordaeskeyfo";

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var fileManager = new FileManager(filePath, encryptionKey);

            if (File.Exists(filePath))
            {
                fileManager.DecryptFile();
            }
            else
            {
                fileManager.CreateFile();
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            var fileManager = new FileManager(filePath, encryptionKey);
            fileManager.EncryptFile();

            base.OnExit(e);
        }
    }
}
