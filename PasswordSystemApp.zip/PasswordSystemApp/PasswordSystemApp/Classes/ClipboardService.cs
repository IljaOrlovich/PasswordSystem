﻿using System.Windows;

namespace PasswordSystemApp.Classes
{
    public static class ClipboardService
    {
        public static void CopyToClipboard(string text)
        {
            Clipboard.SetText(text);
        }
    }
}
