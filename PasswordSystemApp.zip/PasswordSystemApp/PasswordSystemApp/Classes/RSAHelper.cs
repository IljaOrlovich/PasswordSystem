﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace PasswordSystemApp.Classes
{
    public static class RSAHelper
    {
        private static RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);

        static RSAHelper()
        {
            rsa.PersistKeyInCsp = false;
        }

        public static string PublicKey => Convert.ToBase64String(rsa.ExportRSAPublicKey());

        public static string Encrypt(string textToEncrypt)
        {
            var bytesToEncrypt = Encoding.UTF8.GetBytes(textToEncrypt);
            var encryptedBytes = rsa.Encrypt(bytesToEncrypt, false);
            return Convert.ToBase64String(encryptedBytes);
        }

        public static string Decrypt(string textToDecrypt)
        {
            var bytesToDecrypt = Convert.FromBase64String(textToDecrypt);
            var decryptedBytes = rsa.Decrypt(bytesToDecrypt, false);
            return Encoding.UTF8.GetString(decryptedBytes);
        }
    }
}
