﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace PasswordSystemApp.Classes
{
    public class FileManager
    {
        private readonly string _filePath;
        private readonly string _encryptionKey;

        public FileManager(string filePath, string encryptionKey)
        {
            _filePath = filePath;
            _encryptionKey = encryptionKey;
        }

        public void CreateFile()
        {
            using (var sw = File.CreateText(_filePath))
            {
                sw.WriteLine("File created");
            }
        }

        public void EncryptFile()
        {
            if (!File.Exists(_filePath))
                return;

            var plainText = File.ReadAllText(_filePath);
            var encryptedText = EncryptString(plainText, _encryptionKey);
            File.WriteAllText(_filePath, encryptedText);
        }

        public void DecryptFile()
        {
            if (!File.Exists(_filePath))
                return;

            var encryptedText = File.ReadAllText(_filePath);
            var decryptedText = DecryptString(encryptedText, _encryptionKey);
            File.WriteAllText(_filePath, decryptedText);
        }

        public void AddPassword(string name, string password, string urlOrApp, string comment)
        {
            string encryptedPassword = RSAHelper.Encrypt(password);
            string newLine = $"{name},{encryptedPassword},{urlOrApp},{comment}";

            using (StreamWriter sw = File.AppendText(_filePath))
            {
                sw.WriteLine(newLine);
            }
        }

        public string[] FindPasswordByName(string name)
        {
            if (!File.Exists(_filePath))
                return null;

            var lines = File.ReadAllLines(_filePath);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts[0].Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    return parts;
                }
            }
            return null;
        }

        public void UpdatePassword(string name, string newPassword)
        {

            string encryptedPassword = RSAHelper.Encrypt(newPassword);

            string[] lines = File.ReadAllLines(_filePath);


            for (int i = 1; i < lines.Length; i++) 
            {
                var parts = lines[i].Split(',');
                if (parts[0].Equals(name, StringComparison.OrdinalIgnoreCase))
                {

                    parts[1] = encryptedPassword;

                    lines[i] = string.Join(",", parts);
                    break;
                }
            }

            File.WriteAllLines(_filePath, lines);
        }

        public bool DeletePassword(string name)
        {
            string[] lines = File.ReadAllLines(_filePath);

            bool found = false;

            List<string> newLines = new List<string>();

            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts[0].Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    found = true;
                }
                else
                {
                    newLines.Add(line);
                }
            }

            File.WriteAllLines(_filePath, newLines);

            return found;
        }

        private string EncryptString(string plainText, string key)
        {
            using (Aes aes = Aes.Create())
            {
                byte[] keyBytes = Encoding.UTF8.GetBytes(key);
                aes.Key = keyBytes;
                aes.IV = new byte[16];

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    using (StreamWriter sw = new StreamWriter(cs))
                    {
                        sw.Write(plainText);
                    }

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        private string DecryptString(string cipherText, string key)
        {
            using (Aes aes = Aes.Create())
            {
                byte[] keyBytes = Encoding.UTF8.GetBytes(key);
                aes.Key = keyBytes;
                aes.IV = new byte[16];

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(Convert.FromBase64String(cipherText)))
                using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                using (StreamReader sr = new StreamReader(cs))
                {
                    return sr.ReadToEnd();
                }
            }
        }
    }
}
