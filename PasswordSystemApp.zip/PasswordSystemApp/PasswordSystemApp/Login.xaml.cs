﻿using System;
using System.IO;
using System.Windows;
using BCrypt.Net;
using PasswordSystemApp.Classes;

namespace PasswordSystemApp
{
    public partial class Login : Window
    {
        private const string EncryptionKey = "passwordaeskeyfopasswordaeskeyfo";

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string userName = UserName.Text;
            string password = Password.Password;
            string filePath = $"{userName}.txt";

            if (!File.Exists(filePath))
            {
                MessageBox.Show("Invalid username or password.");
                return;
            }

            FileManager fileManager = new FileManager(filePath, EncryptionKey);

            try
            {
                fileManager.DecryptFile();
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] data = line.Split(',');
                    if (data[0] == userName && BCrypt.Net.BCrypt.Verify(password, data[1]))
                    {
                        MessageBox.Show("Login Successful!");  
                        MenuWindow menuWindow = new MenuWindow();
                        menuWindow.Show();
                        this.Close();
                        return;
                        
                    }
                }
                
                fileManager.EncryptFile();
            }
            catch (FormatException)
            {
                MessageBox.Show("Data corruption detected. Please contact support.");
            }

            MessageBox.Show("Invalid username or password.");
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Register register = new Register();
            register.Show();
            this.Close();
        }
    }
}
